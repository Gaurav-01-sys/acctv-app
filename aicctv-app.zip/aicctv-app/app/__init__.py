"""CCTV Analytics backend package."""
